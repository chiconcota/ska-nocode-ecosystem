<?php
defined('ABSPATH') || exit;

// Lấy danh sách bảng từ Ska Data Pro
$data_dictionary = get_option('ska_data_dictionary', []);
$ska_apps = get_option('ska_data_apps', []);
$available_tables = [];
foreach ($data_dictionary as $table_name => $meta) {
    if (isset($meta['__table_info'])) {
        $app_group = 'Ska Smart Object Table';
        $app_id = isset($meta['__table_info']['app_id']) ? $meta['__table_info']['app_id'] : '';

        if ($app_id && $app_id !== 'uncategorized') {
            if (isset($ska_apps[$app_id])) {
                $app_group = 'APP: ' . mb_strtoupper($ska_apps[$app_id]['name'], 'UTF-8');
            } else {
                $app_group = 'APP: ' . strtoupper(str_replace('app_', '', $app_id));
            }
        } elseif (preg_match('/ska_data_app_([^_]+)_/', $table_name, $m)) {
            $app_group = 'APP: ' . strtoupper($m[1]);
        }

        global $wpdb;
        $columns = [];
        
        $wpdb->suppress_errors(true);
        $physical_columns = $wpdb->get_results("SHOW COLUMNS FROM `{$table_name}`");
        $wpdb->suppress_errors(false);
        
        if (!empty($physical_columns)) {
            foreach ($physical_columns as $p_col) {
                $col_key = $p_col->Field;
                
                // Map friendly names from dictionary if available
                $options = null;
                if (isset($meta[$col_key]) && is_array($meta[$col_key])) {
                    $name = isset($meta[$col_key]['title']) ? $meta[$col_key]['title'] : $col_key;
                    $type = isset($meta[$col_key]['type']) ? $meta[$col_key]['type'] : 'text';
                    if (isset($meta[$col_key]['options'])) {
                        $options = $meta[$col_key]['options'];
                    } elseif (isset($meta[$col_key]['choices'])) {
                        $options = $meta[$col_key]['choices'];
                    }
                } else {
                    $name = $col_key;
                    if ($col_key === 'id') $name = 'ID';
                    if ($col_key === 'created_at') $name = 'Ngày tạo (created_at)';
                    
                    $type = 'text';
                    if (strpos(strtolower($p_col->Type), 'int') !== false) $type = 'number';
                    if (strpos(strtolower($p_col->Type), 'datetime') !== false || strpos(strtolower($p_col->Type), 'timestamp') !== false) $type = 'datetime';
                }
                
                $columns[] = [
                    'id' => $col_key,
                    'name' => $name,
                    'type' => $type,
                    'options' => $options
                ];
            }
        } else {
            // Fallback to dictionary if physical table fetch fails
            foreach ($meta as $col_key => $col_data) {
                if ($col_key !== '__table_info' && is_array($col_data)) {
                    $columns[] = [
                        'id' => $col_key,
                        'name' => isset($col_data['title']) ? $col_data['title'] : $col_key,
                        'type' => isset($col_data['type']) ? $col_data['type'] : 'text',
                        'options' => isset($col_data['options']) ? $col_data['options'] : (isset($col_data['choices']) ? $col_data['choices'] : null)
                    ];
                }
            }
        }

        $available_tables[] = [
            'id' => $table_name,
            'name' => $meta['__table_info']['name'],
            'app_group' => $app_group,
            'columns' => $columns
        ];
    }
}

// Danh sách các Cục Node khả dụng (Nhất quán với các Class đã tạo)
$available_nodes = [
    [
        'class' => 'Ska_Format_Processor',
        'name' => '🧰 Định Dạng Dữ Liệu (Chuẩn hóa Rác)',
        'type' => 'processor',
        'color' => '#f59e0b'
    ],
    [
        'class' => 'Ska_Insert_Data_Action',
        'name' => '🗄️ Lưu Xuống Data (Bất kỳ Bảng nào)',
        'type' => 'action',
        'color' => '#10b981'
    ],
    [
        'class' => 'Ska_Update_Data_Action',
        'name' => '📝 Cập Nhật Record (Update)',
        'type' => 'action',
        'color' => '#8b5cf6'
    ],
    [
        'class' => 'Ska_Email_Action',
        'name' => '✉️ Gửi Email (Có {{biến_động}})',
        'type' => 'action',
        'color' => '#3b82f6'
    ]
];

// Lấy danh sách Workflow hiện có
$all_workflows = get_option('ska_logic_simple_workflows', []);
$all_workflow_ids = array_keys($all_workflows);

// Nếu người dùng chọn từ dropdown, load đúng ID đó, nếu không load cái đầu tiên (hoặc default)
$current_wf_id = isset($_GET['workflow_id']) ? sanitize_text_field($_GET['workflow_id']) : (empty($all_workflow_ids) ? 'default_form_submit' : $all_workflow_ids[0]);

$current_wf = isset($all_workflows[$current_wf_id]) ? $all_workflows[$current_wf_id] : [];
$saved_graph = empty($current_wf['graph']) ? '[]' : wp_json_encode($current_wf['graph']);

?>

<style>
    /* Keep a clean layout for the app wrapper */
    .ska-admin-wrapper {
        margin: 20px 20px 20px 0;
    }
    .ska-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #fff;
        padding: 12px 20px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        margin-bottom: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
</style>

<div class="ska-admin-wrapper">
    <div class="ska-header">
        <div style="display:flex; align-items:center; gap:12px;">
            <a href="?page=ska-logic-engine&view=list" class="button"><span class="dashicons dashicons-arrow-left-alt2" style="margin-top:4px;"></span> Trở ra</a>
            <h2 style="margin:0; font-size: 18px; color: #0f172a; font-weight: 600;">
                <span class="dashicons dashicons-networking" style="color: #3b82f6;"></span>
                DAG Automation Builder <span style="color:#64748b; font-weight: 400; font-size: 14px;">(ID: <?php echo esc_html($current_wf_id); ?>)</span>
            </h2>
        </div>
        <form method="POST" id="skaWorkflowForm" style="margin: 0;">
            <?php wp_nonce_field('ska_logic_nonce'); ?>
            <input type="hidden" name="ska_logic_save" value="1">
            <input type="hidden" name="ska_form_id" value="<?php echo esc_attr($current_wf_id); ?>">
            <input type="hidden" name="ska_linear_graph" id="skaLinearGraphInput" value="">
            <button type="submit" class="button button-primary" style="background:#059669; border-color:#059669; font-size: 14px; padding: 0 16px; display:flex; align-items:center; gap:6px;">
                <span class="dashicons dashicons-saved" style="margin-top:0;"></span> Lưu Đồ Thị
            </button>
        </form>
    </div>

    <!-- React Flow Root -->
    <div id="ska-dag-root"></div>
</div>

<script>
    window.SKA_DAG_CONTEXT = {
        DATA_NONCE: "<?php echo esc_js(wp_create_nonce('ska_data_nonce')); ?>",
        AVAILABLE_TABLES: <?php echo wp_json_encode($available_tables); ?>,
        AVAILABLE_NODES: <?php echo wp_json_encode($available_nodes); ?>,
        CURRENT_GRAPH: <?php echo $saved_graph; ?>,
        CURRENT_WF_ID: "<?php echo esc_js($current_wf_id); ?>"
    };
</script>

<?php
// Tự động enqueue Vite bundles
$plugin_url = plugin_dir_url(dirname(__DIR__));
wp_enqueue_style('ska-dag-builder-style', $plugin_url . 'assets/js/admin-dag-builder.bundle.css', [], time());
wp_enqueue_script('ska-dag-builder-script', $plugin_url . 'assets/js/admin-dag-builder.bundle.js', ['wp-element'], time(), true);
?>